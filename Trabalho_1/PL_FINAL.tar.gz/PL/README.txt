Para instalar:

> sudo make install

Para remover:

>sudo make unistal


Para utilizar:

>pppl -l -h fileIn.txt fileOutName

As flag's -l para latex, e -h para html.

>pppl -h fileIn.txt fileOutName

>pppl -l fileIn.txt fileOutName


Para testar:

abrir pasta teste/

>pppl -l -h relatorioppp.txt outfileName

ele irá gera a parte html e flex.




